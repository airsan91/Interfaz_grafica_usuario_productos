package View;

import Controller.CustomerController;
import Controller.ProductoController;
import Model.Customer;
import Model.Producto;
import java.awt.Image;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableModel;

public class Principal extends javax.swing.JFrame {

    private DefaultListModel mdl;
    public Principal() {
        mdl = new DefaultListModel();
        initComponents();
        ProductoController.getInstancia().leerProductos();
        CustomerController.getInstance().readCustomers();
        lstProductos.setListData(ProductoController.getInstancia().getListaProducto().toArray());
        lstCustomer.setListData(CustomerController.getInstance().getListCustomer().toArray());
        
       DefaultListModel model;
        
        model= new DefaultListModel();
        String[]info= new String[5];      
        info[0]=txtCodigoProducto.getText();
        info[1]=txtNombreProducto.getText();
        info[2]=txtCantidadProducto.getText();
        info[3]=txtPrecioProducto.getText();
        info[4]=txtNombreProducto.getText();
        //String.valueOf(Double.parseDouble(txtPrecioProducto.getText())*Double.parseDouble(txtCantidadProducto.getText()));
        
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        estadoProducto = new javax.swing.ButtonGroup();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtDocumentCustomer = new javax.swing.JTextField();
        txtNameCustomer = new javax.swing.JTextField();
        txtAddressCustomer = new javax.swing.JTextField();
        txtPhoneNumberCustomer = new javax.swing.JTextField();
        txtEmailAddressCustomer = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstCustomer = new javax.swing.JList();
        btnAddCustomer = new javax.swing.JButton();
        btnModifyCustomer = new javax.swing.JButton();
        btnEditCustomer = new javax.swing.JButton();
        btnSafeCustomer = new javax.swing.JButton();
        btnDeleteCustomer = new javax.swing.JButton();
        btnCancelCustomer = new javax.swing.JButton();
        btnFileCustomer = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtEconomicStatusCustomer = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        rdbAgeCustomer = new javax.swing.JRadioButton();
        rdbAgeCustomer2 = new javax.swing.JRadioButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtCodigoProducto = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtNombreProducto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtPrecioProducto = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        txtCantidadProducto = new javax.swing.JFormattedTextField();
        btnGuardarProducto = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        rdbEstadoProducto1 = new javax.swing.JRadioButton();
        rdbEstadoProducto2 = new javax.swing.JRadioButton();
        txtFechaProducto = new javax.swing.JFormattedTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstProductos = new javax.swing.JList();
        btnAdicionarProducto = new javax.swing.JButton();
        btnEditarProducto = new javax.swing.JButton();
        btnEliminarProducto = new javax.swing.JButton();
        btnCancelarProducto = new javax.swing.JButton();
        btnModificarProducto = new javax.swing.JButton();
        btnArchivarProductos = new javax.swing.JButton();
        btnAddImage = new javax.swing.JButton();
        lblImageProducto = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));

        jLabel8.setText("Document");

        jLabel9.setText("Name");

        jLabel10.setText("Address");

        jLabel11.setText("Phone number");

        jLabel12.setText("Email address");

        txtDocumentCustomer.setEnabled(false);

        txtNameCustomer.setEnabled(false);

        txtAddressCustomer.setEnabled(false);
        txtAddressCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAddressCustomerActionPerformed(evt);
            }
        });

        txtPhoneNumberCustomer.setEnabled(false);

        txtEmailAddressCustomer.setEnabled(false);

        lstCustomer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstCustomerMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(lstCustomer);

        btnAddCustomer.setText("Add");
        btnAddCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddCustomerActionPerformed(evt);
            }
        });

        btnModifyCustomer.setText("Modify");
        btnModifyCustomer.setEnabled(false);
        btnModifyCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModifyCustomerActionPerformed(evt);
            }
        });

        btnEditCustomer.setText("Edit");
        btnEditCustomer.setEnabled(false);
        btnEditCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditCustomerActionPerformed(evt);
            }
        });

        btnSafeCustomer.setText("Safe");
        btnSafeCustomer.setEnabled(false);
        btnSafeCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSafeCustomerActionPerformed(evt);
            }
        });

        btnDeleteCustomer.setText("Delete");
        btnDeleteCustomer.setEnabled(false);
        btnDeleteCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteCustomerActionPerformed(evt);
            }
        });

        btnCancelCustomer.setText("Cancel");
        btnCancelCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelCustomerActionPerformed(evt);
            }
        });

        btnFileCustomer.setText("File");
        btnFileCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFileCustomerActionPerformed(evt);
            }
        });

        jLabel7.setText("Economic status");

        txtEconomicStatusCustomer.setEnabled(false);
        txtEconomicStatusCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEconomicStatusCustomerActionPerformed(evt);
            }
        });

        jLabel13.setText("Age");

        rdbAgeCustomer.setSelected(true);
        rdbAgeCustomer.setText("Less than 18");
        rdbAgeCustomer.setEnabled(false);
        rdbAgeCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbAgeCustomerActionPerformed(evt);
            }
        });

        rdbAgeCustomer2.setText("More than 18");
        rdbAgeCustomer2.setEnabled(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel8)
                        .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addComponent(btnAddCustomer)
                    .addComponent(jLabel7)
                    .addComponent(jLabel13))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnModifyCustomer)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditCustomer)
                        .addGap(20, 20, 20)
                        .addComponent(btnSafeCustomer)
                        .addGap(18, 18, 18)
                        .addComponent(btnDeleteCustomer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCancelCustomer)
                        .addGap(28, 28, 28)
                        .addComponent(btnFileCustomer))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDocumentCustomer)
                            .addComponent(txtNameCustomer)
                            .addComponent(txtAddressCustomer)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(rdbAgeCustomer)
                                .addGap(18, 18, 18)
                                .addComponent(rdbAgeCustomer2))
                            .addComponent(txtEconomicStatusCustomer)
                            .addComponent(txtEmailAddressCustomer)
                            .addComponent(txtPhoneNumberCustomer))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(107, 107, 107))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtDocumentCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtNameCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtAddressCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(txtPhoneNumberCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtEmailAddressCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtEconomicStatusCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(rdbAgeCustomer)
                            .addComponent(rdbAgeCustomer2)))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddCustomer)
                    .addComponent(btnModifyCustomer)
                    .addComponent(btnEditCustomer)
                    .addComponent(btnSafeCustomer)
                    .addComponent(btnDeleteCustomer)
                    .addComponent(btnCancelCustomer)
                    .addComponent(btnFileCustomer))
                .addContainerGap(50, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Customer", jPanel2);

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));

        tblProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Codigo:", "Nombre Producto:", "Cantidad:", "Valor Unidad:", "Valor Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblProductos);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(262, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(123, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Receipt", jPanel4);

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));
        jPanel1.setEnabled(false);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Code");

        txtCodigoProducto.setEnabled(false);
        txtCodigoProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodigoProductoActionPerformed(evt);
            }
        });

        jLabel2.setText("Name");

        txtNombreProducto.setEnabled(false);
        txtNombreProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreProductoActionPerformed(evt);
            }
        });

        jLabel3.setText("Price");

        txtPrecioProducto.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#######"))));
        txtPrecioProducto.setEnabled(false);
        txtPrecioProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioProductoActionPerformed(evt);
            }
        });

        jLabel4.setText("Amount");

        txtCantidadProducto.setEnabled(false);

        btnGuardarProducto.setText("Safe");
        btnGuardarProducto.setEnabled(false);
        btnGuardarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarProductoActionPerformed(evt);
            }
        });

        jLabel5.setText("Date");

        jLabel6.setText("Status");

        rdbEstadoProducto1.setBackground(new java.awt.Color(204, 204, 255));
        estadoProducto.add(rdbEstadoProducto1);
        rdbEstadoProducto1.setSelected(true);
        rdbEstadoProducto1.setText("Active");
        rdbEstadoProducto1.setEnabled(false);

        rdbEstadoProducto2.setBackground(new java.awt.Color(204, 204, 255));
        estadoProducto.add(rdbEstadoProducto2);
        rdbEstadoProducto2.setText("Inactive");
        rdbEstadoProducto2.setEnabled(false);
        rdbEstadoProducto2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbEstadoProducto2ActionPerformed(evt);
            }
        });

        txtFechaProducto.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat("dd/MM/yyyy"))));
        txtFechaProducto.setEnabled(false);

        lstProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstProductosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(lstProductos);

        btnAdicionarProducto.setText("Add");
        btnAdicionarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarProductoActionPerformed(evt);
            }
        });

        btnEditarProducto.setText("Edit");
        btnEditarProducto.setEnabled(false);
        btnEditarProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEditarProductoMouseClicked(evt);
            }
        });
        btnEditarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarProductoActionPerformed(evt);
            }
        });

        btnEliminarProducto.setText("Delete");
        btnEliminarProducto.setEnabled(false);
        btnEliminarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarProductoActionPerformed(evt);
            }
        });

        btnCancelarProducto.setText("Cancel");
        btnCancelarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarProductoActionPerformed(evt);
            }
        });

        btnModificarProducto.setText("Modify");
        btnModificarProducto.setEnabled(false);
        btnModificarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarProductoActionPerformed(evt);
            }
        });

        btnArchivarProductos.setText("File");
        btnArchivarProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArchivarProductosActionPerformed(evt);
            }
        });

        btnAddImage.setText("Add image");
        btnAddImage.setEnabled(false);
        btnAddImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddImageActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnEditarProducto)
                                .addGap(18, 18, 18)
                                .addComponent(btnGuardarProducto)
                                .addGap(18, 18, 18)
                                .addComponent(btnArchivarProductos))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnEliminarProducto)
                                .addGap(18, 18, 18)
                                .addComponent(btnCancelarProducto)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAdicionarProducto)
                                .addGap(18, 18, 18)
                                .addComponent(btnModificarProducto)
                                .addGap(108, 108, 108))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(rdbEstadoProducto1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(rdbEstadoProducto2))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel2)
                                                    .addComponent(jLabel4)
                                                    .addComponent(jLabel5)
                                                    .addComponent(jLabel6))
                                                .addGap(32, 32, 32))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtCodigoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtCantidadProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtFechaProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(32, 32, 32)))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                                .addComponent(btnAddImage)
                                .addGap(165, 165, 165))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(lblImageProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCodigoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombreProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPrecioProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCantidadProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtFechaProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(rdbEstadoProducto1)
                            .addComponent(rdbEstadoProducto2)))
                    .addComponent(jScrollPane1)
                    .addComponent(lblImageProducto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdicionarProducto)
                    .addComponent(btnModificarProducto)
                    .addComponent(btnAddImage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditarProducto)
                    .addComponent(btnGuardarProducto)
                    .addComponent(btnArchivarProductos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminarProducto)
                    .addComponent(btnCancelarProducto))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Product", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddImageActionPerformed
        String Path="";
        JFileChooser jFileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG, PNG, GIF","jpg", "png", "gif");
        jFileChooser.setFileFilter(filter);

        int answer = jFileChooser.showOpenDialog(this);
        

        if(answer == JFileChooser.APPROVE_OPTION){
           Path = jFileChooser.getSelectedFile().getPath();         
        }
            lblImageProducto.setText(Path);
            Image mImage = new ImageIcon(Path).getImage();
            ImageIcon mIcon = new ImageIcon(mImage.getScaledInstance(lblImageProducto.getWidth(),lblImageProducto.getHeight(), Image.SCALE_SMOOTH));
            lblImageProducto.setIcon(mIcon);

    }//GEN-LAST:event_btnAddImageActionPerformed

    private void btnArchivarProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchivarProductosActionPerformed
        String mensaje = ProductoController.getInstancia().guardarProductos();
        JOptionPane.showMessageDialog(this, mensaje);
    }//GEN-LAST:event_btnArchivarProductosActionPerformed

    private void btnModificarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarProductoActionPerformed
        ProductoController.getInstancia().getProducto().setCodigo(txtCodigoProducto.getText());
        ProductoController.getInstancia().getProducto().setNombre(txtNombreProducto.getText());
        ProductoController.getInstancia().getProducto().setPrecio(Double.parseDouble(txtPrecioProducto.getText()));
        ProductoController.getInstancia().getProducto().setCantidad(Integer.parseInt(txtCantidadProducto.getText()));
        ProductoController.getInstancia().getProducto().setFechaString((txtFechaProducto.getText()));
        boolean estado = true;
        if (rdbEstadoProducto2.isSelected()) {
            estado = false;
        }
        ProductoController.getInstancia().getProducto().setEstado(estado);
        ProductoController.getInstancia().getProducto().setImage(lblImageProducto.getText());
        lstProductos.setListData(ProductoController.getInstancia().getListaProducto().toArray());
        activarDesActivarCamposProducto(false);
        lstProductos.setEnabled(true);
        limpiarCamposProducto();
        activarDesActivarBotonesProducto(true, false, false, false, false, false,false);
        lstProductos.clearSelection();
    }//GEN-LAST:event_btnModificarProductoActionPerformed

    private void btnCancelarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarProductoActionPerformed
        activarDesActivarBotonesProducto(true, false, false, false, false, false,false);
        activarDesActivarCamposProducto(false);
        limpiarCamposProducto();
        lstProductos.clearSelection();
        lstProductos.setEnabled(true);
    }//GEN-LAST:event_btnCancelarProductoActionPerformed

    private void btnEliminarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarProductoActionPerformed
        if (!lstProductos.isSelectionEmpty()) {
            ProductoController.getInstancia().getListaProducto().remove(lstProductos.getSelectedIndex());
            lstProductos.setListData(ProductoController.getInstancia().getListaProducto().toArray());
            limpiarCamposProducto();
            activarDesActivarBotonesProducto(true, false, false, false, false, false,false);
            activarDesActivarCamposProducto(false);
            lstProductos.setEnabled(true);
            lstProductos.clearSelection();
        }
    }//GEN-LAST:event_btnEliminarProductoActionPerformed

    private void btnEditarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarProductoActionPerformed

        activarDesActivarCamposProducto(true);
        activarDesActivarBotonesProducto(false, false, true, false, true, true,true);
        lstProductos.setEnabled(false);
    }//GEN-LAST:event_btnEditarProductoActionPerformed

    private void btnEditarProductoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditarProductoMouseClicked

    }//GEN-LAST:event_btnEditarProductoMouseClicked

    private void btnAdicionarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarProductoActionPerformed
        limpiarCamposProducto();
        activarDesActivarCamposProducto(true);
        activarDesActivarBotonesProducto(false, false, false, true, false, true,true);
    }//GEN-LAST:event_btnAdicionarProductoActionPerformed

    private void lstProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstProductosMouseClicked
        if (!lstProductos.isSelectionEmpty()) {

            ProductoController.getInstancia().setProducto((Producto) lstProductos.getSelectedValue());
            txtCodigoProducto.setText(ProductoController.getInstancia().getProducto().getCodigo());
            txtNombreProducto.setText(ProductoController.getInstancia().getProducto().getNombre());
            txtPrecioProducto.setText(String.valueOf(ProductoController.getInstancia().getProducto().getPrecio()));
            txtCantidadProducto.setText(String.valueOf(ProductoController.getInstancia().getProducto().getCantidad()));
            txtFechaProducto.setText(String.valueOf(ProductoController.getInstancia().getProducto().getFechaString()));
            activarDesActivarBotonesProducto(false, true, false, false, true, true,false);
            if (ProductoController.getInstancia().getProducto().isEstado()) {
                rdbEstadoProducto1.setSelected(true);
            } else {
                rdbEstadoProducto2.setSelected(true);
            }
            Image mImage = new ImageIcon(ProductoController.getInstancia().getProducto().getImage()).getImage();
            ImageIcon mIcon = new ImageIcon(mImage.getScaledInstance(lblImageProducto.getWidth(),lblImageProducto.getHeight(), Image.SCALE_SMOOTH));
            lblImageProducto.setIcon(mIcon);

        }
    }//GEN-LAST:event_lstProductosMouseClicked

    private void rdbEstadoProducto2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbEstadoProducto2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbEstadoProducto2ActionPerformed

    private void btnGuardarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarProductoActionPerformed
        String estado = "Activo";

        if (rdbEstadoProducto2.isSelected()) {
            estado = "Inactivo";
        }

        ProductoController.getInstancia().agregarProducto(ProductoController.getInstancia().getListaProducto().size() + 1,
            txtCodigoProducto.getText(), txtNombreProducto.getText(), txtPrecioProducto.getText(),
            txtCantidadProducto.getText(), txtFechaProducto.getText(), estado, lblImageProducto.getText());

        JOptionPane.showMessageDialog(this, "Producto adicionado correctamente :D");
        limpiarCamposProducto();
        lstProductos.setListData(ProductoController.getInstancia().getListaProducto().toArray());
        activarDesActivarBotonesProducto(true, false, false, false, false, false,false);
        activarDesActivarCamposProducto(false);
    }//GEN-LAST:event_btnGuardarProductoActionPerformed

    private void txtPrecioProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioProductoActionPerformed

    private void txtNombreProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreProductoActionPerformed

    private void txtCodigoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodigoProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodigoProductoActionPerformed

    private void rdbAgeCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbAgeCustomerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbAgeCustomerActionPerformed

    private void txtEconomicStatusCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEconomicStatusCustomerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEconomicStatusCustomerActionPerformed

    private void btnFileCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFileCustomerActionPerformed
        String message = CustomerController.getInstance().safeCustomers();
        JOptionPane.showConfirmDialog(this, message);
    }//GEN-LAST:event_btnFileCustomerActionPerformed

    private void btnCancelCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelCustomerActionPerformed

        activeInactiveButtonsCustomer(true, false, false, false, false, false,false);
        activeInactiveFieldCustomer(false);
        clearFieldCustomer();
        lstCustomer.clearSelection();
        lstCustomer.setEnabled(true);
    }//GEN-LAST:event_btnCancelCustomerActionPerformed

    private void btnDeleteCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteCustomerActionPerformed
        if(!lstCustomer.isSelectionEmpty()){
            CustomerController.getInstance().getListCustomer().remove(lstCustomer.getSelectedIndex());
            lstCustomer.setListData(CustomerController.getInstance().getListCustomer().toArray());
            clearFieldCustomer();
            activeInactiveButtonsCustomer(true, false, false, false, false, false,false);
            activeInactiveFieldCustomer(false);
            lstCustomer.setEnabled(true);
            lstCustomer.clearSelection();
        }
    }//GEN-LAST:event_btnDeleteCustomerActionPerformed

    private void btnSafeCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSafeCustomerActionPerformed

        String age = "Less than 18";

        if (rdbAgeCustomer2.isSelected()) {
            age = "More than 18";
        }

        CustomerController.getInstance().addCustomers(CustomerController.getInstance().getListCustomer().size() + 1,
            txtDocumentCustomer.getText(), txtNameCustomer.getText(), txtAddressCustomer.getText(),
            txtPhoneNumberCustomer.getText(), txtEmailAddressCustomer.getText(), txtEconomicStatusCustomer.getText(), age);
        JOptionPane.showMessageDialog(this, "Customer has been added correctly");
        clearFieldCustomer();
        lstCustomer.setListData(CustomerController.getInstance().getListCustomer().toArray());
        activeInactiveButtonsCustomer(true, false, false, false, false, false,false);
        activeInactiveFieldCustomer(false);
    }//GEN-LAST:event_btnSafeCustomerActionPerformed

    private void btnEditCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditCustomerActionPerformed

        activeInactiveFieldCustomer(true);
        activeInactiveButtonsCustomer(false, false, true, false, true, true,true);
        lstCustomer.setEnabled(false);
    }//GEN-LAST:event_btnEditCustomerActionPerformed

    private void btnModifyCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModifyCustomerActionPerformed
        CustomerController.getInstance().getCustomer().setDocument(Integer.parseInt(txtDocumentCustomer.getText()));
        CustomerController.getInstance().getCustomer().setName(txtNameCustomer.getText());
        CustomerController.getInstance().getCustomer().setAddress(txtAddressCustomer.getText());
        CustomerController.getInstance().getCustomer().setPhoneNumber(Integer.parseInt(txtPhoneNumberCustomer.getText()));
        CustomerController.getInstance().getCustomer().setEmailAddress(txtEmailAddressCustomer.getText());
        CustomerController.getInstance().getCustomer().setEconomicStatus(Integer.parseInt(txtEconomicStatusCustomer.getText()));
        boolean age = true;
        if (rdbAgeCustomer2.isSelected()) {
            age = false;
        }
        CustomerController.getInstance().getCustomer().setAge(age);
        lstCustomer.setListData( CustomerController.getInstance().getListCustomer().toArray());
        activeInactiveFieldCustomer(false);
        lstCustomer.setEnabled(true);
        clearFieldCustomer();
        activeInactiveButtonsCustomer(true, false, false, false, false, false,false);
        lstCustomer.clearSelection();
    }//GEN-LAST:event_btnModifyCustomerActionPerformed

    private void btnAddCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddCustomerActionPerformed
        clearFieldCustomer();
        activeInactiveFieldCustomer(true);
        activeInactiveButtonsCustomer(false, false, false, true, false, true,true);
    }//GEN-LAST:event_btnAddCustomerActionPerformed

    private void lstCustomerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstCustomerMouseClicked
        if (!lstCustomer.isSelectionEmpty()) {
            CustomerController.getInstance().setCustomer((Customer)lstCustomer.getSelectedValue());
            txtDocumentCustomer.setText(String.valueOf(CustomerController.getInstance().getCustomer().getDocument()));
            txtNameCustomer.setText(CustomerController.getInstance().getCustomer().getName());
            txtAddressCustomer.setText(CustomerController.getInstance().getCustomer().getAddress());
            txtPhoneNumberCustomer.setText(String.valueOf(CustomerController.getInstance().getCustomer().getPhoneNumber()));
            txtEmailAddressCustomer.setText(CustomerController.getInstance().getCustomer().getEmailAddress());
            txtEconomicStatusCustomer.setText(String.valueOf(CustomerController.getInstance().getCustomer().getEconomicStatus()));
            activeInactiveButtonsCustomer(false, true, false, false, true, true,true);
            if (CustomerController.getInstance().getCustomer().isAge()) {
                rdbAgeCustomer.setSelected(true);
            } else {
                rdbAgeCustomer2.setSelected(true);
            }

        }
    }//GEN-LAST:event_lstCustomerMouseClicked

    private void txtAddressCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAddressCustomerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAddressCustomerActionPerformed

    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddCustomer;
    private javax.swing.JButton btnAddImage;
    private javax.swing.JButton btnAdicionarProducto;
    private javax.swing.JButton btnArchivarProductos;
    private javax.swing.JButton btnCancelCustomer;
    private javax.swing.JButton btnCancelarProducto;
    private javax.swing.JButton btnDeleteCustomer;
    private javax.swing.JButton btnEditCustomer;
    private javax.swing.JButton btnEditarProducto;
    private javax.swing.JButton btnEliminarProducto;
    private javax.swing.JButton btnFileCustomer;
    private javax.swing.JButton btnGuardarProducto;
    private javax.swing.JButton btnModificarProducto;
    private javax.swing.JButton btnModifyCustomer;
    private javax.swing.JButton btnSafeCustomer;
    private javax.swing.ButtonGroup estadoProducto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblImageProducto;
    private javax.swing.JList lstCustomer;
    private javax.swing.JList lstProductos;
    private javax.swing.JRadioButton rdbAgeCustomer;
    private javax.swing.JRadioButton rdbAgeCustomer2;
    private javax.swing.JRadioButton rdbEstadoProducto1;
    private javax.swing.JRadioButton rdbEstadoProducto2;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtAddressCustomer;
    private javax.swing.JFormattedTextField txtCantidadProducto;
    private javax.swing.JTextField txtCodigoProducto;
    private javax.swing.JTextField txtDocumentCustomer;
    private javax.swing.JTextField txtEconomicStatusCustomer;
    private javax.swing.JTextField txtEmailAddressCustomer;
    private javax.swing.JFormattedTextField txtFechaProducto;
    private javax.swing.JTextField txtNameCustomer;
    private javax.swing.JTextField txtNombreProducto;
    private javax.swing.JTextField txtPhoneNumberCustomer;
    private javax.swing.JFormattedTextField txtPrecioProducto;
    // End of variables declaration//GEN-END:variables

    private void limpiarCamposProducto() {
        txtCodigoProducto.setText("");
        txtNombreProducto.setText("");
        txtPrecioProducto.setText("");
        txtCantidadProducto.setText("");
        txtFechaProducto.setText("");
        rdbEstadoProducto1.setSelected(true);
    }

    private void clearFieldCustomer() {

        txtDocumentCustomer.setText("");
        txtNameCustomer.setText("");
        txtAddressCustomer.setText("");
        txtPhoneNumberCustomer.setText("");
        txtEmailAddressCustomer.setText("");
        txtEconomicStatusCustomer.setText("");
        rdbAgeCustomer.setSelected(true);
    }

    private void activarDesActivarCamposProducto(boolean estado) {
        txtCodigoProducto.setEnabled(estado);
        txtNombreProducto.setEnabled(estado);
        txtPrecioProducto.setEnabled(estado);
        txtCantidadProducto.setEnabled(estado);
        txtFechaProducto.setEnabled(estado);
        rdbEstadoProducto1.setEnabled(estado);
        rdbEstadoProducto2.setEnabled(estado);
        rdbEstadoProducto1.setEnabled(true);
    }

    private void activeInactiveFieldCustomer(boolean estado) {

        txtDocumentCustomer.setEnabled(estado);
        txtNameCustomer.setEnabled(estado);
        txtAddressCustomer.setEnabled(estado);
        txtPhoneNumberCustomer.setEnabled(estado);
        txtEmailAddressCustomer.setEnabled(estado);
        txtEconomicStatusCustomer.setEnabled(estado);
        rdbAgeCustomer.setEnabled(estado);
        rdbAgeCustomer2.setEnabled(estado);
        rdbAgeCustomer.setEnabled(true);
    }

    private void activarDesActivarBotonesProducto(boolean estado1, boolean estado2, boolean estado6, boolean estado3, boolean estado4, boolean estado5, boolean estado7) {
        btnAdicionarProducto.setEnabled(estado1);
        btnEditarProducto.setEnabled(estado2);
        btnModificarProducto.setEnabled(estado6);
        btnGuardarProducto.setEnabled(estado3);
        btnEliminarProducto.setEnabled(estado4);
        btnCancelarProducto.setEnabled(estado5);
        btnAddImage.setEnabled(estado7);

    }

    private void activeInactiveButtonsCustomer(boolean estado1, boolean estado2, boolean estado3, boolean estado4, boolean estado5, boolean estado6, boolean estado7) {
        btnAddCustomer.setEnabled(estado1);
        btnEditCustomer.setEnabled(estado2);
        btnModifyCustomer.setEnabled(estado3);
        btnSafeCustomer.setEnabled(estado4);
        btnDeleteCustomer.setEnabled(estado5);
        btnCancelCustomer.setEnabled(estado6);
        btnAddImage.setEnabled(estado7);
    }
    
   
}
