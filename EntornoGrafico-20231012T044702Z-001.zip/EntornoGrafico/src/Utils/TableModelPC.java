
package Utils;

import Model.Producto;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class TableModelPC{
    private ArrayList<Producto>productos;
    private ArrayList<String>titulos;
    
    public TableModelPC(){
        this.productos=new ArrayList();
        this.titulos=new ArrayList();
        cargarTitulos();
    }
    
    public TableModelPC(ArrayList productos){
        this.productos = productos;
        this.titulos = new ArrayList();
        cargarTitulos();
    }
    
    public int getRowCount(){
        return productos.size();
    }
    
    public int getColumnCount(){
        return titulos.size();
    }
    
    public Object getValueAt(int rowIndex, int columnIndex){
        Producto producto = productos.get(rowIndex);
        switch(columnIndex){
            case 0:
            return producto.getId();
            case 1:
                return producto.getCodigo();
            case 2:
                return producto.getNombre();
            case 3:
                return producto.getPrecio();
            case 4:
                return producto.getCantidad();
            case 5:
                return producto.getPrecio();
            case 6:{
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                return formato.format(producto.getFechaString());
            }
            case 7:{
                if(producto.isEstado())
                    return "Activo";
                return "Inactivo";
            }
            default:
                return null;
        }        
    }
    
    public String getColumnName(int columnIndex){
        return titulos.get(columnIndex);
    }
    
    public Object getValueAt(int rowIndex){
        return productos.get(rowIndex);
    }
    
    private void cargarTitulos(){
        titulos.add("Id");
        titulos.add("Codigo");
        titulos.add("Nombre");
        titulos.add("Precio");
        titulos.add("Cantidad");
        titulos.add("Fecha");
        titulos.add("Estado");
    }
}
