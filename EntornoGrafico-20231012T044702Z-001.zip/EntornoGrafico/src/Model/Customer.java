
package Model;

import java.util.StringTokenizer;

public class Customer {
    private int id;
    private int document;
    private String name;
    private String address;
    private int phoneNumber;
    private String emailAddress;
    private int economicStatus;
    private boolean age;

    public Customer(int id, int document, String name, String address, int phoneNumber,String emailAddress, int economicStatus, boolean age) {
        this.id = id;
        this.document = document;
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.economicStatus = economicStatus;
        this.age = age;
    }
    
    
    public Customer(String line){
        StringTokenizer token = new StringTokenizer(line,"*");
        id = Integer.parseInt(token.nextToken());
        document = Integer.parseInt(token.nextToken());
        name = token.nextToken();
        address = token.nextToken();
        phoneNumber = Integer.parseInt(token.nextToken());    
        emailAddress = token.nextToken();
        economicStatus = Integer.parseInt(token.nextToken());
        age = Boolean.parseBoolean(token.nextToken());
        
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDocument() {
        return document;
    }

    public void setDocument(int document) {
        this.document = document;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public int getEconomicStatus() {
        return economicStatus;
    }

    public void setEconomicStatus(int economicStatus) {
        this.economicStatus = economicStatus;
    }

    public boolean isAge() {
        return age;
    }

    public void setAge(boolean age) {
        this.age = age;
    }
       
    
    public String toString(){
        return name;
    }
    
    
    
    public String toRegister(){
        return id + "*" +document +"*"+ name +"*"+ address +"*"+ phoneNumber +"*"+ emailAddress +"*"+ economicStatus +"*"+ age;
        
    }
    
}
