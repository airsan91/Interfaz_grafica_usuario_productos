
package Model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Producto {
    private int id;
    private String codigo;
    private String nombre;
    private double precio;
    private int cantidad;
    private Date fecha;
    private boolean estado;
    private String image;

    public Producto(int id, String codigo, String nombre, double precio, int cantidad, Date fecha, boolean estado, String image) {
        this.id = id;
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
        this.fecha = fecha;
        this.estado = estado;
        this.image = image;
    }
    
    public Producto(String linea){
        StringTokenizer token = new StringTokenizer(linea,"*");
        id = Integer.parseInt(token.nextToken());
        codigo = token.nextToken();
        nombre = token.nextToken();
        precio = Double.parseDouble(token.nextToken());
        cantidad = Integer.parseInt(token.nextToken());
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        try {
            fecha = formato.parse(token.nextToken());
        } catch (ParseException ex) {
            fecha = new Date();
        }
        estado = Boolean.parseBoolean(token.nextToken());
        image = token.nextToken();
        
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getFechaString() {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        return formato.format(fecha);
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    
    public void setFechaString(String fecha) {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        try {
            this.fecha = formato.parse(fecha);
        } catch (ParseException ex) {
            this.fecha=new Date();
            
        }
    }
    

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
    public String toString(){
        return nombre;
    }
    
    public String toRegistro(){
        
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        
        return id + "*" +codigo +"*"+ nombre +"*"+ precio +"*"+ cantidad +"*"+ formato.format(fecha) +"*"+ estado +"*"+ image;
        
    }
    
}
