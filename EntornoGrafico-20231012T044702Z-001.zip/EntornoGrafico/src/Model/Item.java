
package Model;

public class Item {
    private int amount;
    private double unitValue;

    public Item(int amount, double unitValue) {
        this.amount = amount;
        this.unitValue = unitValue;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getUnitValue() {
        return unitValue;
    }

    public void setUnitValue(double unitValue) {
        this.unitValue = unitValue;
    }
    
    
}
