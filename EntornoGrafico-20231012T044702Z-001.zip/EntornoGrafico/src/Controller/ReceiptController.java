
package Controller;

import Model.Item;
import Utils.Receipt;
import java.util.ArrayList;

public class ReceiptController {
    private ArrayList<Receipt>listReceipt;
    private ArrayList<Item>listItem;
    private Receipt receipt;
    private static ReceiptController receiptController;

    public ReceiptController() {
        listReceipt = new ArrayList();
        listItem = new ArrayList();
    }
    
    
     public static ReceiptController getInstance(){
        if(receiptController == null){
            return receiptController = new ReceiptController();
        }
        else{
            return receiptController;
        }
    }

    public ArrayList<Receipt> getListReceipt() {
        return listReceipt;
    }

    public void setListReceipt(ArrayList<Receipt> listReceipt) {
        this.listReceipt = listReceipt;
    }

    public ArrayList<Item> getListItem() {
        return listItem;
    }

    public void setListItem(ArrayList<Item> listItem) {
        this.listItem = listItem;
    }

    public Receipt getReceipt() {
        return receipt;
    }

    public void setReceipt(Receipt receipt) {
        this.receipt = receipt;
    }

    public static ReceiptController getReceiptController() {
        return receiptController;
    }

    public static void setReceiptController(ReceiptController receiptController) {
        ReceiptController.receiptController = receiptController;
    }
     
    
    
}
