
package Controller;

import Model.Customer;
import Persistencia.CustomerDAO;
import Persistencia.ProductoDAO;
import java.util.ArrayList;

public class CustomerController {
    private ArrayList<Customer>listCustomer;
    private Customer customer;
    private static CustomerController customerController;
    
    private CustomerController(){
        listCustomer = new ArrayList();
    }
    
    public static CustomerController getInstance(){
        if(customerController == null){
            return customerController = new CustomerController();
        }
        else{
            return customerController;
        }
    }
    
    public ArrayList<Customer>getListCustomer(){
        return listCustomer;
    }
    
    public void setListCustomer(ArrayList<Customer>listCustomer){
        this.listCustomer=listCustomer;
    }
    
    public Customer getCustomer(){
        return customer;
    }
    
    public void setCustomer(Customer customer){
        this.customer=customer;
    }
    
    public void addCustomers(int id, String document, String name, String address, String phoneNumber, String emailAddress, String economicStatus, String age){
        boolean age1;
        if(age.equals("Less than 18"))
            age1=true;
        else
            age1=false;
        customer = new Customer(id, Integer.parseInt(document), name, address, Integer.parseInt(phoneNumber), emailAddress, Integer.parseInt(economicStatus), age1);
        listCustomer.add(customer);
    }
    
    
    public String safeCustomers(){
        return CustomerDAO.instance().guardarCustomer(listCustomer);
    }
    
     public void readCustomers(){
        listCustomer = CustomerDAO.instance().readCustomers();
    }
    
}
