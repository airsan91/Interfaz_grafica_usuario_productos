
package Controller;

import Model.Producto;
import Persistencia.ProductoDAO;
import Utils.Receipt;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ProductoController {
    private ArrayList<Producto>listaProducto;
    private Producto producto;
    private static ProductoController productoController;

    private ProductoController() {
        listaProducto = new ArrayList();
    }

    public static ProductoController getInstancia(){
        if(productoController == null){
            return productoController = new ProductoController();
        }
        else{
            return productoController;
        }
    }
    public ArrayList<Producto> getListaProducto() {
        return listaProducto;
    }

    public void setListaProducto(ArrayList<Producto> listaProducto) {
        this.listaProducto = listaProducto;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }
     
    
    public void agregarProducto(int id, String codigo, String nombre, String precio, String cantidad, String fecha, String estado, String image){
        
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        boolean estado1;
        if(estado.equals("Activo"))
            estado1 = true;
        else
            estado1 = false;
        
        Date fechaProducto = new Date();
        try {
            fechaProducto = formato.parse(fecha);
        } catch (ParseException ex) {
            fechaProducto = new Date();
        }
        
        producto = new Producto(id, codigo, nombre, Double.parseDouble(precio), Integer.parseInt(cantidad), fechaProducto, estado1, image);
        listaProducto.add(producto);
        
    }

    public String guardarProductos(){
        return ProductoDAO.instancia().guardarProducto(listaProducto);
    }
    
    public void leerProductos(){
        listaProducto = ProductoDAO.instancia().leerProductos();
    }
    
    public Receipt listarProductos(){
        if(listaProducto!=null){
            return new Receipt(listaProducto);
        }else{
            return new Receipt();
        }
    }

}
