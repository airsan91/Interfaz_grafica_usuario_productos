
package Persistencia;

import Controller.ProductoController;
import Model.Producto;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ProductoDAO {
    private final String fileName;
    private BufferedWriter bw;
    private BufferedReader br;
    private static ProductoDAO productoDAO;
    
    private ProductoDAO(){
        fileName = "productos.txt";
            
    }
    
    
    public static ProductoDAO instancia(){
         if(productoDAO == null){
            return productoDAO = new ProductoDAO();
        }
        else{
            return productoDAO;
        }
    }
    
    public String guardarProducto(ArrayList<Producto>productos){
        String mensaje = "";
        
        try{
        bw = new BufferedWriter(new FileWriter(fileName));
        for(Producto producto: productos){
            bw.append(producto.toRegistro());
            bw.newLine();
        }
        bw.close();
        mensaje = "El archivo fue creado exitosamente :D";
        }
        catch(IOException e){
            mensaje = "No se pudo crear el archivo :´(" + e.getMessage();
        }
        return mensaje;
    }
    public ArrayList<Producto> leerProductos(){
        String linea = "";
        ArrayList<Producto>productos=new ArrayList();
        try {
            br = new BufferedReader(new FileReader(fileName));
            linea = br.readLine();
            while(linea != null){
                Producto producto = new Producto(linea);
                productos.add(producto);
                linea = br.readLine();
            }
            br.close();
            
        } catch (IOException ex) {
            Logger.getLogger(ProductoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return productos;
    }
}
