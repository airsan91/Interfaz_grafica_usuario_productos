
package Persistencia;

import Model.Customer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerDAO {
    
    private final String fileName;
    private BufferedWriter bw;
    private BufferedReader br;
    private static CustomerDAO customerDAO;
    
    private CustomerDAO(){
        fileName = "customer.txt";
    }
    
    public static CustomerDAO instance(){
        if(customerDAO==null){
            return customerDAO = new CustomerDAO();
        }
        else{
            return customerDAO;
        }
    }
    
    
        public String guardarCustomer(ArrayList<Customer>customers){
        String message = "";
        
        try{
        bw = new BufferedWriter(new FileWriter(fileName));
        for(Customer customer: customers){
            bw.append(customer.toRegister());
            bw.newLine();
        }
        bw.close();
        message = "El archivo fue creado exitosamente :D";
        }
        catch(IOException e){
            message = "No se pudo crear el archivo :´(" + e.getMessage();
        }
        return message;
        }    
        
        
        public ArrayList<Customer>readCustomers(){
        String line = "";
        ArrayList<Customer>customers=new ArrayList();
        try {
            br = new BufferedReader(new FileReader(fileName));
            line = br.readLine();
            while(line != null){
                Customer customer = new Customer(line);
                customers.add(customer);
                line = br.readLine();
            }
            br.close();
            
        } catch (IOException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return customers;
    }
        
}
